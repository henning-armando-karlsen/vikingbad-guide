import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Home from './pages/Home';
import Auth from './pages/Auth';
import LandingSelectRole from './pages/LandingSelectRole';
import VikingbadStudioSertifisering from './pages/VikingbadStudioSertifisering';
import ModulePage from './pages/ModulePage';
import KundereisePage from './pages/KundereisePage';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/auth" element={<Auth />} />
          <Route path="/" element={<LandingSelectRole />} />
          <Route path="/home" element={
            <ProtectedRoute>
              <Home />
            </ProtectedRoute>
          } />
          <Route path="/level/1" element={
            <ProtectedRoute>
              <VikingbadStudioSertifisering />
            </ProtectedRoute>
          } />
          <Route path="/studio" element={
            <ProtectedRoute>
              <VikingbadStudioSertifisering />
            </ProtectedRoute>
          } />
          <Route path="/vikingbad-studio-sertifisering/modul/:moduleId" element={
            <ProtectedRoute>
              <ModulePage />
            </ProtectedRoute>
          } />
          <Route path="/kundereise" element={
            <ProtectedRoute>
              <KundereisePage />
            </ProtectedRoute>
          } />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;
