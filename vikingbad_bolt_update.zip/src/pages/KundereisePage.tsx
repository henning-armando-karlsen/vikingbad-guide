import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function KundereisePage() {
  const navigate = useNavigate();

  return (
    <div style={{ position: 'fixed', inset: 0, display: 'flex', flexDirection: 'column', background: '#1A1A1A' }}>
      {/* Thin top bar med tilbake-knapp */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        padding: '8px 16px',
        background: '#1A1A1A',
        borderBottom: '1px solid rgba(203,196,175,0.15)',
        flexShrink: 0,
        zIndex: 10,
      }}>
        <button
          onClick={() => navigate(-1)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '6px 14px',
            background: 'transparent',
            border: '1px solid rgba(203,196,175,0.3)',
            borderRadius: '6px',
            color: 'rgba(203,196,175,0.8)',
            fontSize: '0.8rem',
            fontWeight: 600,
            cursor: 'pointer',
            fontFamily: 'Manrope, sans-serif',
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
            transition: 'all 0.15s',
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLButtonElement).style.background = 'rgba(203,196,175,0.1)';
            (e.currentTarget as HTMLButtonElement).style.color = 'rgba(203,196,175,1)';
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLButtonElement).style.background = 'transparent';
            (e.currentTarget as HTMLButtonElement).style.color = 'rgba(203,196,175,0.8)';
          }}
        >
          <ArrowLeft size={14} />
          Tilbake
        </button>

        <span style={{
          color: 'rgba(203,196,175,0.4)',
          fontSize: '0.75rem',
          fontFamily: 'Manrope, sans-serif',
          letterSpacing: '0.1em',
          textTransform: 'uppercase',
        }}>
          Vikingbad Studio · Komplett prosessguide
        </span>
      </div>

      {/* Full-screen iframe med prosessguiden */}
      <iframe
        src="/kundereiseguide.html"
        style={{
          flex: 1,
          border: 'none',
          width: '100%',
          height: '100%',
        }}
        title="Vikingbad Studio — Komplett prosessguide"
        allow="fullscreen"
      />
    </div>
  );
}
